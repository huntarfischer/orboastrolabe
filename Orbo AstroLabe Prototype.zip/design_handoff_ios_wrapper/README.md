# Handoff: Orbo Astrolabe — iOS App Wrapper

## Overview
Orbo Astrolabe is a single-file web app (an astrological visualization/instrument tool). It currently runs by uploading the HTML file to a web host and opening it in mobile Safari/Chrome. This handoff is to wrap it as a real installable iOS app using a WKWebView shell — **not** a UI rewrite.

## About the design file
`orbo-astrolabe.html` in this folder is a fully self-contained, offline-capable build of the production app — HTML/CSS/JS and all data (ephemeris, city lookup) inlined into one file. It is not a mockup; it is the actual app. The task is to embed this exact file into a native iOS shell and fix one known layout bug (below) — do not reimplement the UI natively, and do not modify the app's internals beyond the viewport fix unless asked.

## Recommended approach: Capacitor
Fastest path to an App-Store-able binary without hand-rolling Xcode/WKWebView plumbing:
1. `npm init` a minimal wrapper project, `npm install @capacitor/core @capacitor/cli @capacitor/ios`
2. `npx cap init` (app name "Orbo Astrolabe", bundle id e.g. `com.<you>.orboastrolabe`)
3. Create a `www/` folder containing just `index.html` = a copy of `orbo-astrolabe.html`
4. `capacitor.config.json`: set `webDir: "www"`
5. `npx cap add ios` → opens a generated Xcode project under `ios/`
6. Open in Xcode, set app icon + launch screen, set orientation to Portrait only (this design is a fixed 430px-max-width phone layout, not responsive to landscape)
7. Build to a physical device via Xcode (needs an Apple Developer account for a real device; simulator works without one)

Plain-WKWebView alternative (skip Capacitor): a blank Xcode "App" project, single `WKWebView` in the root view controller loading `orbo-astrolabe.html` from the app bundle via `loadFileURL`. More manual, no plugin ecosystem, but zero extra dependencies — reasonable if Capacitor feels like overkill for one file.

## Known bug to fix before/during wrapping
**The moon (pull-up) panel gets clipped when the browser's address/toolbar is showing**, because the app shell is sized with `min-height: 100vh` in two places (the outer wrapper and the ~430px-max-width column). Mobile Safari/Chrome's `100vh` includes the area *behind* the collapsing toolbar, so the real visible viewport is shorter than `100vh` whenever the toolbar is on-screen — content anchored to the bottom (the moon panel) ends up below the fold.

Fix: replace `min-height:100vh` with `min-height:100dvh` (dynamic viewport height unit, handles the collapsing toolbar correctly) with a `100vh` fallback for older WebKit, e.g.:
```css
min-height: 100vh;
min-height: 100dvh;
```
This matters even inside the native wrapper: a WKWebView has no browser toolbar, so the bug disappears there, but the same file is still being used for web/PWA access (per the user's current workflow) — fix it once, benefits both.

## Other native-shell considerations
- Add `<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">` (viewport-fit=cover is needed for edge-to-edge on notch/Dynamic-Island devices) and pad safe areas with `env(safe-area-inset-*)` if any chrome (header, big-three ticker) should avoid the notch/home indicator.
- Disable the WebView's bounce/rubber-band scroll (`UIScrollView.bounces = false` on the WKWebView's scroll view, or `overscroll-behavior: none` in CSS) — the app isn't a scrolling page, it's a fixed-viewport instrument.
- `localStorage` (used for the saved-charts/settings state) persists fine inside a WKWebView, same as Safari — no changes needed there.
- Lock orientation to Portrait in the Xcode project (Info.plist `UISupportedInterfaceOrientations`) since the layout is a fixed phone-width column.
- App icon/launch screen: the file already has a data-URI icon inlined (used for the web `<link rel="apple-touch-icon">`) — reuse that art at proper native icon resolutions (1024×1024 master) rather than relying on the inlined small version.

## Files
- `orbo-astrolabe.html` — the complete, self-contained app to embed as-is (mirrors the project's `Orbo Astrolabe.dc.html`, V0.71, bundled for offline use).
